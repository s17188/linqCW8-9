﻿namespace LinqCwiczenia
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ResultsDataGridView = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.WynikTextBox = new System.Windows.Forms.TextBox();
            this.WartoscLabel = new System.Windows.Forms.Label();
            this.Przyklad10Button = new System.Windows.Forms.Button();
            this.Przyklad9Button = new System.Windows.Forms.Button();
            this.Przyklad8Button = new System.Windows.Forms.Button();
            this.Przyklad7Button = new System.Windows.Forms.Button();
            this.Przyklad6Button = new System.Windows.Forms.Button();
            this.Przyklad5Button = new System.Windows.Forms.Button();
            this.Przyklad4Button = new System.Windows.Forms.Button();
            this.Przyklad3Button = new System.Windows.Forms.Button();
            this.Przyklad2Button = new System.Windows.Forms.Button();
            this.Przyklad1Button = new System.Windows.Forms.Button();
            this.ResetButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ResultsDataGridView)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ResultsDataGridView
            // 
            this.ResultsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ResultsDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ResultsDataGridView.Location = new System.Drawing.Point(0, 0);
            this.ResultsDataGridView.Name = "ResultsDataGridView";
            this.ResultsDataGridView.Size = new System.Drawing.Size(924, 429);
            this.ResultsDataGridView.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.WynikTextBox);
            this.panel1.Controls.Add(this.WartoscLabel);
            this.panel1.Controls.Add(this.Przyklad10Button);
            this.panel1.Controls.Add(this.Przyklad9Button);
            this.panel1.Controls.Add(this.Przyklad8Button);
            this.panel1.Controls.Add(this.Przyklad7Button);
            this.panel1.Controls.Add(this.Przyklad6Button);
            this.panel1.Controls.Add(this.Przyklad5Button);
            this.panel1.Controls.Add(this.Przyklad4Button);
            this.panel1.Controls.Add(this.Przyklad3Button);
            this.panel1.Controls.Add(this.Przyklad2Button);
            this.panel1.Controls.Add(this.Przyklad1Button);
            this.panel1.Controls.Add(this.ResetButton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 357);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(924, 72);
            this.panel1.TabIndex = 1;
            // 
            // WynikTextBox
            // 
            this.WynikTextBox.Location = new System.Drawing.Point(605, 14);
            this.WynikTextBox.Name = "WynikTextBox";
            this.WynikTextBox.Size = new System.Drawing.Size(307, 20);
            this.WynikTextBox.TabIndex = 12;
            // 
            // WartoscLabel
            // 
            this.WartoscLabel.AutoSize = true;
            this.WartoscLabel.Location = new System.Drawing.Point(549, 17);
            this.WartoscLabel.Name = "WartoscLabel";
            this.WartoscLabel.Size = new System.Drawing.Size(50, 13);
            this.WartoscLabel.TabIndex = 11;
            this.WartoscLabel.Text = "Wartość:";
            // 
            // Przyklad10Button
            // 
            this.Przyklad10Button.Location = new System.Drawing.Point(453, 41);
            this.Przyklad10Button.Name = "Przyklad10Button";
            this.Przyklad10Button.Size = new System.Drawing.Size(75, 23);
            this.Przyklad10Button.TabIndex = 10;
            this.Przyklad10Button.Text = "Przykład 10";
            this.Przyklad10Button.UseVisualStyleBackColor = true;
            this.Przyklad10Button.Click += new System.EventHandler(this.Przyklad10Button_Click);
            // 
            // Przyklad9Button
            // 
            this.Przyklad9Button.Location = new System.Drawing.Point(372, 41);
            this.Przyklad9Button.Name = "Przyklad9Button";
            this.Przyklad9Button.Size = new System.Drawing.Size(75, 23);
            this.Przyklad9Button.TabIndex = 9;
            this.Przyklad9Button.Text = "Przykład 9";
            this.Przyklad9Button.UseVisualStyleBackColor = true;
            this.Przyklad9Button.Click += new System.EventHandler(this.Przyklad9Button_Click);
            // 
            // Przyklad8Button
            // 
            this.Przyklad8Button.Location = new System.Drawing.Point(291, 41);
            this.Przyklad8Button.Name = "Przyklad8Button";
            this.Przyklad8Button.Size = new System.Drawing.Size(75, 23);
            this.Przyklad8Button.TabIndex = 8;
            this.Przyklad8Button.Text = "Przykład 8";
            this.Przyklad8Button.UseVisualStyleBackColor = true;
            this.Przyklad8Button.Click += new System.EventHandler(this.Przyklad8Button_Click);
            // 
            // Przyklad7Button
            // 
            this.Przyklad7Button.Location = new System.Drawing.Point(210, 41);
            this.Przyklad7Button.Name = "Przyklad7Button";
            this.Przyklad7Button.Size = new System.Drawing.Size(75, 23);
            this.Przyklad7Button.TabIndex = 7;
            this.Przyklad7Button.Text = "Przykład 7";
            this.Przyklad7Button.UseVisualStyleBackColor = true;
            this.Przyklad7Button.Click += new System.EventHandler(this.Przyklad7Button_Click);
            // 
            // Przyklad6Button
            // 
            this.Przyklad6Button.Location = new System.Drawing.Point(129, 41);
            this.Przyklad6Button.Name = "Przyklad6Button";
            this.Przyklad6Button.Size = new System.Drawing.Size(75, 23);
            this.Przyklad6Button.TabIndex = 6;
            this.Przyklad6Button.Text = "Przykład 6";
            this.Przyklad6Button.UseVisualStyleBackColor = true;
            this.Przyklad6Button.Click += new System.EventHandler(this.Przyklad6Button_Click);
            // 
            // Przyklad5Button
            // 
            this.Przyklad5Button.Location = new System.Drawing.Point(453, 12);
            this.Przyklad5Button.Name = "Przyklad5Button";
            this.Przyklad5Button.Size = new System.Drawing.Size(75, 23);
            this.Przyklad5Button.TabIndex = 5;
            this.Przyklad5Button.Text = "Przykład 5";
            this.Przyklad5Button.UseVisualStyleBackColor = true;
            this.Przyklad5Button.Click += new System.EventHandler(this.Przyklad5Button_Click);
            // 
            // Przyklad4Button
            // 
            this.Przyklad4Button.Location = new System.Drawing.Point(372, 12);
            this.Przyklad4Button.Name = "Przyklad4Button";
            this.Przyklad4Button.Size = new System.Drawing.Size(75, 23);
            this.Przyklad4Button.TabIndex = 4;
            this.Przyklad4Button.Text = "Przykład 4";
            this.Przyklad4Button.UseVisualStyleBackColor = true;
            this.Przyklad4Button.Click += new System.EventHandler(this.Przyklad4Button_Click);
            // 
            // Przyklad3Button
            // 
            this.Przyklad3Button.Location = new System.Drawing.Point(291, 12);
            this.Przyklad3Button.Name = "Przyklad3Button";
            this.Przyklad3Button.Size = new System.Drawing.Size(75, 23);
            this.Przyklad3Button.TabIndex = 3;
            this.Przyklad3Button.Text = "Przykład 3";
            this.Przyklad3Button.UseVisualStyleBackColor = true;
            this.Przyklad3Button.Click += new System.EventHandler(this.Przyklad3Button_Click);
            // 
            // Przyklad2Button
            // 
            this.Przyklad2Button.Location = new System.Drawing.Point(210, 12);
            this.Przyklad2Button.Name = "Przyklad2Button";
            this.Przyklad2Button.Size = new System.Drawing.Size(75, 23);
            this.Przyklad2Button.TabIndex = 2;
            this.Przyklad2Button.Text = "Przykład 2";
            this.Przyklad2Button.UseVisualStyleBackColor = true;
            this.Przyklad2Button.Click += new System.EventHandler(this.Przyklad2Button_Click);
            // 
            // Przyklad1Button
            // 
            this.Przyklad1Button.Location = new System.Drawing.Point(129, 12);
            this.Przyklad1Button.Name = "Przyklad1Button";
            this.Przyklad1Button.Size = new System.Drawing.Size(75, 23);
            this.Przyklad1Button.TabIndex = 1;
            this.Przyklad1Button.Text = "Przykład 1";
            this.Przyklad1Button.UseVisualStyleBackColor = true;
            this.Przyklad1Button.Click += new System.EventHandler(this.Przyklad1Button_Click);
            // 
            // ResetButton
            // 
            this.ResetButton.Location = new System.Drawing.Point(12, 12);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(75, 23);
            this.ResetButton.TabIndex = 0;
            this.ResetButton.Text = "Reset";
            this.ResetButton.UseVisualStyleBackColor = true;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(924, 429);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ResultsDataGridView);
            this.Name = "Form1";
            this.Text = "Ćwiczenia LINQ";
            ((System.ComponentModel.ISupportInitialize)(this.ResultsDataGridView)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView ResultsDataGridView;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button ResetButton;
        private System.Windows.Forms.Button Przyklad1Button;
        private System.Windows.Forms.Button Przyklad2Button;
        private System.Windows.Forms.Button Przyklad3Button;
        private System.Windows.Forms.Button Przyklad4Button;
        private System.Windows.Forms.Button Przyklad5Button;
        private System.Windows.Forms.Button Przyklad6Button;
        private System.Windows.Forms.Button Przyklad7Button;
        private System.Windows.Forms.Button Przyklad8Button;
        private System.Windows.Forms.Button Przyklad9Button;
        private System.Windows.Forms.Button Przyklad10Button;
        private System.Windows.Forms.Label WartoscLabel;
        private System.Windows.Forms.TextBox WynikTextBox;
    }
}

